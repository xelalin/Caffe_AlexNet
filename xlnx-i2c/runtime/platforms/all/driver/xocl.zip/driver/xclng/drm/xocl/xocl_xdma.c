#include "xocl_drv.h"
#include "xocl_xdma.h"
#include "libxdma_api.h"

int xdma_init_glue(struct drm_xocl_dev *xdev)
{
	int ret = 0;
	int user = 0;
	xdev->xdma_handle = (struct xdma_dev *) xdma_device_open(DRV_NAME, xdev->ddev->pdev, &user,
								 &xdev->channel, &xdev->channel);
	if (xdev->xdma_handle == NULL) {
		DRM_INFO("%s: XDMA Device Open failed. \n", DRV_NAME);
		ret = -ENOENT;	// TBD: Get the error code from XDMA API.
	}
	DRM_INFO("%s: XDMA Device Open successful. \n", DRV_NAME);
	return ret;
}

void xdma_fini_glue(struct drm_xocl_dev *xdev)
{
	xdma_device_close(xdev->ddev->pdev, xdev->xdma_handle);
	xdev->xdma_handle = NULL;
	DRM_INFO("%s: XDMA Device Close successful. \n", DRV_NAME);
}


int xdma_migrate_bo(const struct drm_xocl_dev *xdev, struct sg_table *sgt, bool write,
		    u64 paddr, int channel)
{
	struct page *pg;
	struct scatterlist *sg = sgt->sgl;
	int nents = sgt->orig_nents;
	pid_t pid = current->pid;
	const char* dirstr = write ? "to" : "from";
	int i = 0;
	int ret;
	unsigned long long pgaddr;
	DRM_DEBUG("%s TID %d, Channel:"
		  "%d, Offset: 0x%llx, Direction: %d\n", __func__, pid, channel, paddr, write ? 1 : 0);
	ret = xdma_xfer_submit(xdev->xdma_handle, channel, write ? 1 : 0, paddr, sgt, false, 10000);
	if (ret >= 0)
		return ret;

	DRM_ERROR("DMA failed %s device addr 0x%llx, tid %d, channel %d\n", dirstr, paddr, pid, channel);
	DRM_ERROR("Dumping SG Page Table\n");
	for (i = 0; i < nents; i++, sg = sg_next(sg)) {
        if (!sg)
            break;
		pg = sg_page(sg);
		if (!pg)
			continue;
		pgaddr = page_to_phys(pg);
		DRM_ERROR("%i, 0x%llx\n", i, pgaddr);
	}
	return ret;
}

irqreturn_t xocl_xdma_isr(int irq, void *arg)
{
//	struct drm_device *ddev = (struct drm_device *)arg;
//	struct drm_xocl_dev *xdev = ddev->dev_private;
	return IRQ_HANDLED;
}
