/*
 * A GEM style device manager for PCIe based OpenCL accelerators.
 *
 * Copyright (C) 2016-2017 Xilinx, Inc. All rights reserved.
 *
 * Authors:
 *    Sonal Santan <sonal.santan@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <linux/module.h>
#include <linux/version.h>
#if LINUX_VERSION_CODE <= KERNEL_VERSION(3,0,0)
#include <drm/drm_backport.h>
#endif
#include <drm/drmP.h>
#include <drm/drm_gem.h>
#include <linux/aer.h>
#include "xocl_drv.h"
#include "xocl_ioctl.h"
#include "xocl_xdma.h"

#define XOCL_DRIVER_NAME        "xocl"
#define XOCL_DRIVER_DESC        "Xilinx PCIe OpenCL Device Manager"
#define XOCL_DRIVER_DATE        "20170621"
#define XOCL_DRIVER_MAJOR       2017
#define XOCL_DRIVER_MINOR       1
#define XOCL_DRIVER_PATCHLEVEL  13


#define XOCL_DRIVER_VERSION      \
	__stringify(XOCL_DRIVER_MAJOR) "." \
	__stringify(XOCL_DRIVER_MINOR) "." \
	__stringify(XOCL_DRIVER_PATCHLEVEL)

#define XOCL_DRIVER_VERSION_NUMBER  \
	((XOCL_DRIVER_MAJOR)*1000 + (XOCL_DRIVER_MINOR)*100 + XOCL_DRIVER_PATCHLEVEL)


#define XOCL_FILE_PAGE_OFFSET   0x100000
#define XOCL_FEATURE_ROM_BASE   0x0B0000

#ifndef VM_RESERVED
#define VM_RESERVED (VM_DONTEXPAND | VM_DONTDUMP)
#endif

static const struct pci_device_id pciidlist[] = {
	{ PCI_DEVICE(0x10ee, 0x4A28), },
	{ PCI_DEVICE(0x10ee, 0x4B28), },
	{ PCI_DEVICE(0x10ee, 0x6830), },
	{ PCI_DEVICE(0x10ee, 0x6930), },
	{ PCI_DEVICE(0x10ee, 0x6A30), },
	{ PCI_DEVICE(0x10ee, 0x6D30), },
	{ PCI_DEVICE(0x10ee, 0x4908), },
	{ PCI_DEVICE(0x10ee, 0x4828), },
	{ PCI_DEVICE(0x10ee, 0x4808), },
	{ PCI_DEVICE(0x10ee, 0x2808), },
	{ PCI_DEVICE(0x1d0f, 0x1042), },
	{ 0, }
};

MODULE_DEVICE_TABLE(pci, pciidlist);

static void xocl_print_dev_info(const struct drm_xocl_dev *xdev)
{
	DRM_INFO("%s [Timestamp 0x%llx]\n", xdev->header.VBNVName, xdev->header.TimeSinceEpoch);
	DRM_INFO("%d bi-directional DMA channels\n", xdev->channel);
	DRM_INFO("%d DDR channels, Total RAM=%dGB\n", xdev->header.DDRChannelCount,
		 xdev->header.DDRChannelSize * xdev->header.DDRChannelCount);
	DRM_INFO("PCI Resource 0x%llx [Size 0x%llxKB]\n", xdev->res_start, xdev->res_len/1024);
}

static int probe_feature_rom(struct drm_xocl_dev *xdev)
{
	u32 val;
	unsigned short ddr = (xdev->ddev->pdev->subsystem_device >> 12) & 0x000f;
	val = ioread32(xdev->user_bar + XOCL_FEATURE_ROM_BASE);
	// Magic number check
	if (val != 0x786e6c78) {
		DRM_ERROR("Probe of Feature ROM failed\n");
		return -ENODEV;
	}
	memcpy_fromio(&xdev->header, xdev->user_bar + XOCL_FEATURE_ROM_BASE, sizeof(struct FeatureRomHeader));
	// Sanity check
	if (ddr != xdev->header.DDRChannelCount) {
		DRM_ERROR("Feature ROM DDR channel count not consistent\n");
		return -ENODEV;
	}
	return 0;
}

static int xocl_drm_load(struct drm_device *ddev, unsigned long flags)
{
	struct drm_xocl_dev *xdev;
	unsigned i;
	int result = 0;
	unsigned long long segment = 0;
	unsigned short ddr;
	unsigned long long ddr_size;

#if LINUX_VERSION_CODE <= KERNEL_VERSION(4,4,0)
	drm_dev_set_unique(ddev, dev_name(ddev->dev));
#endif

	xdev = devm_kzalloc(ddev->dev, sizeof(*xdev), GFP_KERNEL);
	if (!xdev)
		return -ENOMEM;
	xdev->ddev = ddev;
	ddev->dev_private = xdev;

	xdev->res_start = pci_resource_start(xdev->ddev->pdev, 0);
	xdev->res_len = pci_resource_end(xdev->ddev->pdev, 0) - xdev->res_start + 1;

	xdev->user_bar = pci_iomap(xdev->ddev->pdev, 0, xdev->res_len);
	if (!xdev->user_bar)
		return -EIO;

	result = probe_feature_rom(xdev);
	if (result)
		goto bar_cleanup;

	ddr = xocl_ddr_channel_count(ddev);
	ddr_size = xocl_ddr_channel_size(ddev);

	xdev->mm = devm_kzalloc(ddev->dev, sizeof(struct drm_mm) * ddr, GFP_KERNEL);
	if (!xdev->mm) {
		result = -ENOMEM;
		goto bar_cleanup;
	}

	for (i = 0; i < ddr; i++) {
		drm_mm_init(&xdev->mm[i], segment, ddr_size);
		segment += ddr_size;
	}

	mutex_init(&xdev->mm_lock);
	// Now call XDMA core init
	DRM_INFO("Enable XDMA core\n");
	result = xdma_init_glue(xdev);
	if (result) {
		DRM_ERROR("XDMA device initialization failed with err code: %d\n", result);
		goto mm_cleanup;
	}

	DRM_INFO("%s:%d:%s()", __FILE__, __LINE__, __func__);

	sema_init(&xdev->channel_sem[0], xdev->channel);
	sema_init(&xdev->channel_sem[1], xdev->channel);
	/* Initialize bit mask to represent individual channels */
	xdev->channel_bitmask[0] = BIT(xdev->channel);
	xdev->channel_bitmask[0]--;
	xdev->channel_bitmask[1] = xdev->channel_bitmask[0];

	mutex_init(&xdev->stat_lock);
	xdev->offline = false;
	xocl_print_dev_info(xdev);

	dev_set_drvdata(&xdev->ddev->pdev->dev, xdev->ddev);

	return 0;

mm_cleanup:
	for (i = 0; i < ddr; i++) {
		drm_mm_takedown(&xdev->mm[i]);
	}
	DRM_INFO("%s:%d:%s()", __FILE__, __LINE__, __func__);
bar_cleanup:
	pci_iounmap(xdev->ddev->pdev, xdev->user_bar);
	xdev->user_bar = NULL;
	return result;
}

static int xocl_drm_unload(struct drm_device *drm)
{
	int i = 0;
	struct drm_xocl_dev *xdev = drm->dev_private;
	const unsigned short ddr = xocl_ddr_channel_count(drm);

	for (i = 0; i < ddr; i++) {
		drm_mm_takedown(&xdev->mm[i]);
	}
	xdev->offline = true;
	pci_iounmap(xdev->ddev->pdev, xdev->user_bar);
	xdma_fini_glue(xdev);
	return 0;
}

static void xocl_free_object(struct drm_gem_object *obj)
{
	xocl_free_bo(obj);
}

static int xocl_mmap(struct file *filp, struct vm_area_struct *vma)
{
	int ret;
	struct drm_file *priv = filp->private_data;
	struct drm_device *dev = priv->minor->dev;
	struct drm_xocl_dev *xdev = dev->dev_private;
	struct mm_struct *mm = current->mm;
	unsigned long vsize;

	//DRM_DEBUG("mmap operation 0x%lx 0x%lx 0x%lx\n", vma->vm_start, vma->vm_end, vma->vm_pgoff);
	/* If the page offset is > than 4G, then let GEM handle that and do what
	 * it thinks is best,we will only handle page offsets less than 4G.
	 */
	if (likely(vma->vm_pgoff >= XOCL_FILE_PAGE_OFFSET)) {
		ret = drm_gem_mmap(filp, vma);
		if (ret)
			return ret;
		/* Clear VM_PFNMAP flag set by drm_gem_mmap()
		 * we have "struct page" for all backing pages for bo
		 */
		vma->vm_flags &= ~VM_PFNMAP;
		/* Clear VM_IO flag set by drm_gem_mmap()
		 * it prevents gdb from accessing mapped buffers
		 */
		vma->vm_flags &= ~VM_IO;
		vma->vm_flags |= VM_MIXEDMAP;
		vma->vm_flags |= mm->def_flags;
		vma->vm_pgoff = 0;

		/* Override pgprot_writecombine() mapping setup by drm_gem_mmap()
		 * which results in very poor read performance
		 */
		if (vma->vm_flags & (VM_READ | VM_MAYREAD))
			vma->vm_page_prot = vm_get_page_prot(vma->vm_flags);
		else
			vma->vm_page_prot = pgprot_writecombine(vm_get_page_prot(vma->vm_flags));
		return ret;
	}

	if (vma->vm_pgoff != 0)
		return -EINVAL;

	vsize = vma->vm_end - vma->vm_start;
	if (vsize > xdev->res_len)
		return -EINVAL;

	vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
	vma->vm_flags |= VM_IO;
	vma->vm_flags |= VM_RESERVED;

	ret = io_remap_pfn_range(vma, vma->vm_start,
				 xdev->res_start >> PAGE_SHIFT,
				 vsize, vma->vm_page_prot);
	DRM_INFO("io_remap_pfn_range ret code: %d", ret);

	return ret;

}

int xocl_gem_fault(struct vm_area_struct *vma, struct vm_fault *vmf)
{
	struct drm_xocl_bo *xobj = to_xocl_bo(vma->vm_private_data);
	loff_t num_pages;
	unsigned int page_offset;
	int ret = 0;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,10,0)
	page_offset = (vmf->address - vma->vm_start) >> PAGE_SHIFT;
#else
	page_offset = ((unsigned long)vmf->virtual_address - vma->vm_start) >> PAGE_SHIFT;
#endif

	if (!xobj->pages)
		return VM_FAULT_SIGBUS;

	num_pages = DIV_ROUND_UP(xobj->base.size, PAGE_SIZE);
	if (page_offset > num_pages)
		return VM_FAULT_SIGBUS;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,10,0)
	ret = vm_insert_page(vma, vmf->address, xobj->pages[page_offset]);
#else
	ret = vm_insert_page(vma, (unsigned long)vmf->virtual_address, xobj->pages[page_offset]);
#endif
	switch (ret) {
	case -EAGAIN:
	case 0:
	case -ERESTARTSYS:
		return VM_FAULT_NOPAGE;
	case -ENOMEM:
		return VM_FAULT_OOM;
	default:
		return VM_FAULT_SIGBUS;
	}
}

static int xocl_info_ioctl(struct drm_device *dev,
			void *data,
			struct drm_file *filp)
{
	struct drm_xocl_info *obj = data;
	struct drm_xocl_dev *xdev = dev->dev_private;
	struct pci_dev *pdev = xdev->ddev->pdev;
	printk(KERN_INFO "%s %s INFO IOCTL \n", DRV_NAME, __FUNCTION__);

	obj->vendor = pdev->vendor;
	obj->device = pdev->device;
	obj->subsystem_vendor = pdev->subsystem_vendor;
	obj->subsystem_device = pdev->subsystem_device;
	obj->driver_version = XOCL_DRIVER_VERSION_NUMBER;
	obj->pci_slot = PCI_SLOT(pdev->devfn);

	printk(KERN_INFO "%s %s PCI Slot: %d \n", DRV_NAME, __FUNCTION__, obj->pci_slot);
	return 0;
}

static const struct drm_ioctl_desc xocl_ioctls[] = {
	DRM_IOCTL_DEF_DRV(XOCL_CREATE_BO, xocl_create_bo_ioctl,
			  DRM_AUTH|DRM_UNLOCKED|DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(XOCL_USERPTR_BO, xocl_userptr_bo_ioctl,
			  DRM_AUTH|DRM_UNLOCKED|DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(XOCL_MAP_BO, xocl_map_bo_ioctl,
			  DRM_AUTH|DRM_UNLOCKED|DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(XOCL_SYNC_BO, xocl_sync_bo_ioctl,
			  DRM_AUTH|DRM_UNLOCKED|DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(XOCL_INFO_BO, xocl_info_bo_ioctl,
			  DRM_AUTH|DRM_UNLOCKED|DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(XOCL_PWRITE_BO, xocl_pwrite_bo_ioctl,
			  DRM_AUTH|DRM_UNLOCKED|DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(XOCL_PREAD_BO, xocl_pread_bo_ioctl,
			  DRM_AUTH|DRM_UNLOCKED|DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(XOCL_CREATE_CTX, xocl_create_ctx_ioctl,
			  DRM_AUTH|DRM_UNLOCKED|DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(XOCL_INFO, xocl_info_ioctl,
			  DRM_AUTH|DRM_UNLOCKED|DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(XOCL_PWRITE_UNMGD, xocl_pwrite_unmgd_ioctl,
			  DRM_AUTH|DRM_UNLOCKED|DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(XOCL_PREAD_UNMGD, xocl_pread_unmgd_ioctl,
			  DRM_AUTH|DRM_UNLOCKED|DRM_RENDER_ALLOW),

};

static const struct file_operations xocl_driver_fops = {
	.owner		= THIS_MODULE,
	.open		= drm_open,
	.mmap		= xocl_mmap,
	.poll		= drm_poll,
	.read		= drm_read,
	.unlocked_ioctl = drm_ioctl,
	.release	= drm_release,
};

static const struct vm_operations_struct xocl_vm_ops = {
	.fault = xocl_gem_fault,
	.open = drm_gem_vm_open,
	.close = drm_gem_vm_close,
};

static struct drm_driver xocl_drm_driver = {
//	.driver_features		= DRIVER_GEM | DRIVER_PRIME |
//					  DRIVER_RENDER | DRIVER_HAVE_IRQ,
	.driver_features		= DRIVER_GEM | DRIVER_PRIME |
	                                  DRIVER_RENDER,
	.load				= xocl_drm_load,
	.unload				= xocl_drm_unload,
	.gem_free_object		= xocl_free_object,
	.gem_vm_ops			= &xocl_vm_ops,
	.prime_handle_to_fd		= drm_gem_prime_handle_to_fd,
	.prime_fd_to_handle		= drm_gem_prime_fd_to_handle,
	.gem_prime_import		= drm_gem_prime_import,
	.gem_prime_export		= drm_gem_prime_export,
	.gem_prime_get_sg_table         = xocl_gem_prime_get_sg_table,
	.gem_prime_import_sg_table      = xocl_gem_prime_import_sg_table,
	.gem_prime_vmap                 = xocl_gem_prime_vmap,
	.gem_prime_vunmap               = xocl_gem_prime_vunmap,
	.irq_handler                    = xocl_xdma_isr,
	.ioctls				= xocl_ioctls,
	.num_ioctls			= ARRAY_SIZE(xocl_ioctls),
	.fops				= &xocl_driver_fops,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3, 18, 0)
	.set_busid                      = drm_pci_set_busid,
#endif
	.name				= XOCL_DRIVER_NAME,
	.desc				= XOCL_DRIVER_DESC,
	.date				= XOCL_DRIVER_DATE,
	.major				= XOCL_DRIVER_MAJOR,
	.minor				= XOCL_DRIVER_MINOR,
	.patchlevel			= XOCL_DRIVER_PATCHLEVEL,
};

static int xocl_pci_probe(struct pci_dev *pdev,
			  const struct pci_device_id *ent)
{
	DRM_INFO("%s:%d:%s()", __FILE__, __LINE__, __func__);
	return drm_get_pci_dev(pdev, ent, &xocl_drm_driver);
}

static void xocl_pci_remove(struct pci_dev *pdev)
{
	struct drm_device *dev = pci_get_drvdata(pdev);
	DRM_INFO("%s:%d:%s()", __FILE__, __LINE__, __func__);
	drm_put_dev(dev);
}

static pci_ers_result_t xocl_error_detected(struct pci_dev *pdev,
					    pci_channel_state_t state)
{
	struct xdma_pci_dev *xpdev = dev_get_drvdata(&pdev->dev);

	switch (state) {
	case pci_channel_io_normal:
		return PCI_ERS_RESULT_CAN_RECOVER;
	case pci_channel_io_frozen:
		DRM_INFO("dev 0x%p,0x%p, frozen state error, reset controller\n",
			 pdev, xpdev);
		//xdma_dev_disable(xpdev, false);
		return PCI_ERS_RESULT_NEED_RESET;
	case pci_channel_io_perm_failure:
		DRM_INFO("dev 0x%p,0x%p, failure state error, req. disconnect\n",
			 pdev, xpdev);
		return PCI_ERS_RESULT_DISCONNECT;
	}
	return PCI_ERS_RESULT_NEED_RESET;
}

static pci_ers_result_t xocl_slot_reset(struct pci_dev *pdev)
{
	struct drm_device *ddev = pci_get_drvdata(pdev);

	DRM_INFO("0x%p restart after slot reset\n", ddev->dev_private);
	pci_restore_state(pdev);
	//queue_work(xdma_workq, &dev->reset_work);
	return PCI_ERS_RESULT_RECOVERED;
}

static void xocl_error_resume(struct pci_dev *pdev)
{
	struct drm_device *ddev = pci_get_drvdata(pdev);

	DRM_INFO("dev 0x%p,0x%p.\n", pdev, ddev->dev_private);
	pci_cleanup_aer_uncorrect_error_status(pdev);
}

void xocl_reset_notify(struct pci_dev *pdev, bool prepare)
{
	struct drm_device *ddev = dev_get_drvdata(&pdev->dev);
	struct drm_xocl_dev *xdev;

	if(ddev) {
		xdev = ddev->dev_private;
	}
	else {
		DRM_ERROR("%s: %s ddev is null", DRV_NAME, __FUNCTION__);
		return;
	}

	if(xdev)
		DRM_INFO("%s: %s dev 0x%p,0x%p, prepare %d.\n", DRV_NAME, __FUNCTION__,
				pdev, ddev->dev_private, prepare);
	else {
		DRM_ERROR("%s: %s xdev is null", DRV_NAME, __FUNCTION__);
		return;
	}

	if (prepare) {
		xdev->offline = true;
		xdma_device_offline(pdev, xdev->xdma_handle);
	}
	else {
		xdma_device_online(pdev, xdev->xdma_handle);
		xdev->offline = false;
	}
}
EXPORT_SYMBOL_GPL(xocl_reset_notify);

static const struct pci_error_handlers xocl_err_handler = {
	.error_detected	= xocl_error_detected,
	.slot_reset	= xocl_slot_reset,
	.resume		= xocl_error_resume,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,16,0)
	.reset_notify	= xocl_reset_notify,
#endif
};


static struct pci_driver xocl_pci_driver = {
	.name = XOCL_DRIVER_NAME,
	.id_table = pciidlist,
	.probe = xocl_pci_probe,
	.remove = xocl_pci_remove,
	.err_handler = &xocl_err_handler,
};

/* init xilinx opencl drm platform */
static int __init xocl_init(void)
{
	DRM_INFO("%s:%d:%s()", __FILE__, __LINE__, __func__);
	return drm_pci_init(&xocl_drm_driver, &xocl_pci_driver);
}

static void __exit xocl_exit(void)
{
	drm_pci_exit(&xocl_drm_driver, &xocl_pci_driver);
}

module_init(xocl_init);
module_exit(xocl_exit);


MODULE_VERSION(__stringify(XOCL_DRIVER_MAJOR) "."
	       __stringify(XOCL_DRIVER_MINOR) "."
	       __stringify(XOCL_DRIVER_PATCHLEVEL));

MODULE_DESCRIPTION(XOCL_DRIVER_DESC);
MODULE_AUTHOR("Sonal Santan <sonal.santan@xilinx.com>");
MODULE_LICENSE("GPL");
