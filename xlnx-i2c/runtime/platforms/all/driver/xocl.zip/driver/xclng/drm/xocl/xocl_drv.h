/*
 * A GEM style device manager for PCIe based OpenCL accelerators.
 *
 * Copyright (C) 2016 Xilinx, Inc. All rights reserved.
 *
 * Authors:
 *    Sonal Santan <sonal.santan@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef _XCL_XOCL_DRV_H_
#define _XCL_XOCL_DRV_H_

#include <linux/version.h>
#if LINUX_VERSION_CODE <= KERNEL_VERSION(3,0,0)
#include <drm/drm_backport.h>
#endif
#include <drm/drmP.h>
#include <drm/drm_gem.h>
#include <drm/drm_mm.h>
#include <linux/semaphore.h>
#include "xclfeatures.h"
#include "xocl_ioctl.h"
#include "libxdma.h"

#define DRV_NAME "xocl"

#define XOCL_BO_USERPTR (1 << 31)
#define XOCL_BO_IMPORT (1 << 30)
#define XOCL_BO_DDR0 (1 << 0)
#define XOCL_BO_DDR1 (1 << 1)
#define XOCL_BO_DDR2 (1 << 2)
#define XOCL_BO_DDR3 (1 << 3)

#define XOCL_CHANNEL_COUNT 	4
#define XOCL_RD_MTX  		0
#define XOCL_WR_MTX  		1

struct drm_xocl_bo {
	/* drm base object */
	struct drm_gem_object base;
	struct drm_mm_node   *mm_node;
	struct page         **pages;
	struct sg_table      *sgt;
	void                 *vmapping;
	unsigned              flags;
};

struct drm_xocl_stat {
	size_t memory_usage;
	unsigned int bo_count;
};

struct drm_xocl_unmgd {
	struct page         **pages;
	struct sg_table      *sgt;
	unsigned int          npages;
	unsigned              flags;
};

struct drm_xocl_dev {
	struct drm_device       *ddev;
	/* The feature Rom header */
	struct FeatureRomHeader  header;
	/* Number of bidirectional channels */
	unsigned                 channel;
	/* Memory manager array, one per DDR channel */
	struct drm_mm           *mm;
	/* Memory manager lock */
	struct mutex             mm_lock;
	/* Semaphore, one for each direction */
	struct semaphore         channel_sem[2];
	/* Channel usage bitmasks, one for each direction
	 * bit 1 indicates channel is free, bit 0 indicates channel is free
	 */
	volatile unsigned long   channel_bitmask[2];
	struct drm_xocl_stat     usage_stat;
	struct xdma_dev         *xdma_handle;
	bool                     offline;
	/* Lock for stats */
	struct mutex             stat_lock;
	void *__iomem            user_bar;
	phys_addr_t              res_start;
	resource_size_t          res_len;
};


static inline struct drm_xocl_bo *to_xocl_bo(struct drm_gem_object *bo)
{
	return (struct drm_xocl_bo *)bo;
}

static inline struct drm_xocl_dev *bo_xocl_dev(const struct drm_xocl_bo *bo)
{
	return bo->base.dev->dev_private;
}

static inline unsigned xocl_bo_ddr_idx(unsigned flags)
{
	const unsigned ddr = flags & 0xf;
	if (!ddr)
		return 0xffffffff;
	return __builtin_ctz(ddr);
}

static inline unsigned short xocl_ddr_channel_count(const struct drm_device *drm)
{
	struct drm_xocl_dev *xdev = drm->dev_private;
	return xdev->header.DDRChannelCount;
}

static inline unsigned long long xocl_ddr_channel_size(const struct drm_device *drm)
{
	struct drm_xocl_dev *xdev = drm->dev_private;
	/* Channel size is in GB */
	return xdev->header.DDRChannelSize * 0x40000000ull;
}

static inline bool xocl_bo_userptr(const struct drm_xocl_bo *bo)
{
	return (bo->flags & XOCL_BO_USERPTR);
}

static inline bool xocl_bo_import(const struct drm_xocl_bo *bo)
{
	return (bo->flags & XOCL_BO_IMPORT);
}

int xocl_create_bo_ioctl(struct drm_device *dev, void *data,
			 struct drm_file *filp);
int xocl_userptr_bo_ioctl(struct drm_device *dev,
			  void *data,
			  struct drm_file *filp);
int xocl_sync_bo_ioctl(struct drm_device *dev, void *data,
		       struct drm_file *filp);
int xocl_map_bo_ioctl(struct drm_device *dev, void *data,
		      struct drm_file *filp);
int xocl_info_bo_ioctl(struct drm_device *dev, void *data,
		       struct drm_file *filp);
int xocl_pwrite_bo_ioctl(struct drm_device *dev, void *data,
			 struct drm_file *filp);
int xocl_pread_bo_ioctl(struct drm_device *dev, void *data,
			struct drm_file *filp);
int xocl_create_ctx_ioctl(struct drm_device *dev, void *data,
			  struct drm_file *filp);
int xocl_pwrite_unmgd_ioctl(struct drm_device *dev, void *data,
			    struct drm_file *filp);
int xocl_pread_unmgd_ioctl(struct drm_device *dev, void *data,
			   struct drm_file *filp);

void xocl_describe(const struct drm_xocl_bo *obj);

void xocl_free_bo(struct drm_gem_object *obj);

int xocl_migrate_bo(struct drm_device *ddev, const struct drm_xocl_bo *xobj,
		    enum drm_xocl_sync_bo_dir dir);

irqreturn_t xocl_xdma_isr(int irq, void *ddev);

/**
 * DMA-BUF support
 */
struct drm_gem_object *xocl_gem_prime_import_sg_table(struct drm_device *dev,
						      struct dma_buf_attachment *attach, struct sg_table *sgt);

struct sg_table *xocl_gem_prime_get_sg_table(struct drm_gem_object *obj);

void *xocl_gem_prime_vmap(struct drm_gem_object *obj);

void xocl_gem_prime_vunmap(struct drm_gem_object *obj, void *vaddr);

#endif
