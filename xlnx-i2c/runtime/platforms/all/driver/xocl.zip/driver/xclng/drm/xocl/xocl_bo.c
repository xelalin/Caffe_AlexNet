/*
 * A GEM style device manager for PCIe based OpenCL accelerators.
 *
 * Copyright (C) 2016-2017 Xilinx, Inc. All rights reserved.
 *
 * Authors:
 *    Sonal Santan <sonal.santan@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <linux/bitops.h>
#include <linux/swap.h>
#include <linux/dma-buf.h>
#include <linux/version.h>
#if LINUX_VERSION_CODE <= KERNEL_VERSION(3,0,0)
#include <drm/drm_backport.h>
#endif
#include <drm/drmP.h>
#include "xocl_drv.h"
#include "xocl_ioctl.h"
#include "xocl_xdma.h"

static inline struct drm_gem_object *xocl_gem_object_lookup(struct drm_device *dev,
							    struct drm_file *filp,
							    u32 handle)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,7,0)
	return drm_gem_object_lookup(filp, handle);
#else
	return drm_gem_object_lookup(dev, filp, handle);
#endif
}

static inline void __user *to_user_ptr(u64 address)
{
	return (void __user *)(uintptr_t)address;
}

void xocl_describe(const struct drm_xocl_bo *xobj)
{
	size_t size_in_kb = xobj->base.size / 1024;
	size_t physical_addr = xobj->mm_node->start;
	unsigned ddr = xocl_bo_ddr_idx(xobj->flags);
	unsigned userptr = xocl_bo_userptr(xobj) ? 1 : 0;

	DRM_DEBUG("%p: H[%p] SIZE[0x%zxKB] D[0x%zx] DDR[%u] UPTR[%u]\n",
		  xobj, xobj->vmapping, size_in_kb, physical_addr, ddr, userptr);
}

void xocl_free_bo(struct drm_gem_object *obj)
{
	struct drm_xocl_bo *xobj = to_xocl_bo(obj);
	int npages = obj->size >> PAGE_SHIFT;
	struct drm_xocl_dev *xdev = obj->dev->dev_private;
	//DRM_DEBUG("Freeing BO %p\n", xobj);

	mutex_lock(&xdev->stat_lock);
	xdev->usage_stat.memory_usage -= obj->size;
	xdev->usage_stat.bo_count--;
	mutex_unlock(&xdev->stat_lock);

	drm_gem_object_release(obj);

	if (xobj->vmapping)
		vunmap(xobj->vmapping);
	xobj->vmapping = NULL;

	if (xobj->pages) {
		if (xocl_bo_userptr(xobj)) {
			release_pages(xobj->pages, npages, 0);
			drm_free_large(xobj->pages);
		}
		else if (!xocl_bo_import(xobj)) {
			drm_gem_put_pages(obj, xobj->pages, false, false);
		}
	}

	xobj->pages = NULL;
	if (xobj->sgt)
		sg_free_table(xobj->sgt);
	xobj->sgt = NULL;

	if (xobj->mm_node) {
		mutex_lock(&xdev->mm_lock);
		drm_mm_remove_node(xobj->mm_node);
		mutex_unlock(&xdev->mm_lock);
		kfree(xobj->mm_node);
	}
	xobj->mm_node = NULL;
	kfree(xobj);
}



static struct drm_xocl_bo *xocl_create_bo(struct drm_device *dev,
					  uint64_t unaligned_size,
					  unsigned flags)
{
	size_t size = PAGE_ALIGN(unaligned_size);
	struct drm_xocl_bo *xobj;
	struct drm_xocl_dev *xdev = dev->dev_private;
	unsigned ddr = xocl_bo_ddr_idx(flags);
	const unsigned ddr_count = xocl_ddr_channel_count(dev);
	int err = 0;

	if (!size)
		return ERR_PTR(-EINVAL);

	/* Either none or only one DDR should be specified */
	if ((ddr != 0xffffffff) && (ddr >= xocl_ddr_channel_count(dev)))
		return ERR_PTR(-EINVAL);

	xobj = kzalloc(sizeof(*xobj), GFP_KERNEL);
	if (!xobj)
		return ERR_PTR(-ENOMEM);

	err = drm_gem_object_init(dev, &xobj->base, size);
	if (err)
		goto out3;

	xobj->mm_node = kzalloc(sizeof(*xobj->mm_node), GFP_KERNEL);
	if (!xobj->mm_node) {
		err = -ENOMEM;
		goto out3;
	}

	mutex_lock(&xdev->mm_lock);
	if (ddr != 0xffffffff) {
		/* Attempt to allocate buffer on the requested DDR */
		err = drm_mm_insert_node_generic(&xdev->mm[ddr], xobj->mm_node, xobj->base.size,
						 PAGE_SIZE, 0, 0, 0);
		if (err)
			goto out2;
	}
	else {
		/* Attempt to allocate buffer on any DDR */
		for (ddr = 0; ddr < ddr_count; ddr++) {
			DRM_DEBUG("%s:%s:%d: %u\n", __FILE__, __func__, __LINE__, ddr);
			err = drm_mm_insert_node_generic(&xdev->mm[ddr], xobj->mm_node, xobj->base.size,
							 PAGE_SIZE, 0, 0, 0);
			if (err == 0)
				break;
		}
		if (err)
			goto out2;
	}
	mutex_unlock(&xdev->mm_lock);
	/* Record the DDR we allocated the buffer on */
	xobj->flags |= (1 << ddr);

	mutex_lock(&xdev->stat_lock);
	xdev->usage_stat.memory_usage += xobj->base.size;
	xdev->usage_stat.bo_count++;
	mutex_unlock(&xdev->stat_lock);
	return xobj;
out2:
	mutex_unlock(&xdev->mm_lock);
	kfree(xobj->mm_node);
	drm_gem_object_release(&xobj->base);
out3:
	kfree(xobj);
	return ERR_PTR(err);
}

int xocl_create_bo_ioctl(struct drm_device *dev,
			 void *data,
			 struct drm_file *filp)
{
	int ret;
	struct drm_xocl_create_bo *args = data;
	struct drm_xocl_bo *xobj;
	unsigned ddr = 0;

	if (args->flags) {
		ddr = (args->flags >> 28) & 0xf;
		if (hweight_long(ddr) > 1)
			return -EINVAL;
	}

	xobj = xocl_create_bo(dev, args->size, args->flags);

	if (IS_ERR(xobj)) {
		DRM_DEBUG("object creation failed\n");
		return PTR_ERR(xobj);
	}

	xobj->pages = drm_gem_get_pages(&xobj->base);
	if (IS_ERR(xobj->pages)) {
		ret = PTR_ERR(xobj->pages);
		goto out_free;
	}

	xobj->sgt = drm_prime_pages_to_sg(xobj->pages, xobj->base.size >> PAGE_SHIFT);
	if (IS_ERR(xobj->sgt)) {
		ret = PTR_ERR(xobj->sgt);
		goto out_free;
	}

	xobj->vmapping = vmap(xobj->pages, xobj->base.size >> PAGE_SHIFT, VM_MAP,
			     pgprot_writecombine(PAGE_KERNEL));

	if (!xobj->vmapping) {
		ret = -ENOMEM;
		goto out_free;
	}

	ret = drm_gem_create_mmap_offset(&xobj->base);
	if (ret < 0)
		goto out_free;

	ret = drm_gem_handle_create(filp, &xobj->base, &args->handle);
	if (ret < 0)
		goto out_free;

	xocl_describe(xobj);
	drm_gem_object_unreference_unlocked(&xobj->base);
	return ret;

out_free:
	xocl_free_bo(&xobj->base);
	return ret;
}

int xocl_userptr_bo_ioctl(struct drm_device *dev,
			  void *data,
			  struct drm_file *filp)
{
	int ret;
	struct drm_xocl_bo *xobj;
	unsigned ddr;
	unsigned int page_count;
	struct drm_xocl_userptr_bo *args = data;

	if (offset_in_page(args->addr))
		return -EINVAL;

	if (args->flags) {
		ddr = (args->flags >> 28) & 0xf;
		if (hweight_long(ddr) > 1)
			return -EINVAL;
	}

	xobj = xocl_create_bo(dev, args->size, args->flags);

	if (IS_ERR(xobj)) {
		DRM_DEBUG("object creation failed\n");
		return PTR_ERR(xobj);
	}

	/* Use the page rounded size so we can accurately account for number of pages */
	page_count = xobj->base.size >> PAGE_SHIFT;

	xobj->pages = drm_malloc_ab(page_count, sizeof(*xobj->pages));
	if (!xobj->pages) {
		ret = -ENOMEM;
		goto out1;
	}
	ret = get_user_pages_fast(args->addr, page_count, 1, xobj->pages);

	if (ret != page_count)
		goto out0;

	xobj->sgt = drm_prime_pages_to_sg(xobj->pages, page_count);
	if (IS_ERR(xobj->sgt)) {
		ret = PTR_ERR(xobj->sgt);
		goto out0;
	}

	/* TODO: resolve the cache issue */
	xobj->vmapping = vmap(xobj->pages, page_count, VM_MAP,
//			      pgprot_writecombine(PAGE_KERNEL));
			      pgprot_noncached(PAGE_KERNEL));

	if (!xobj->vmapping) {
		ret = -ENOMEM;
		goto out1;
	}

	ret = drm_gem_handle_create(filp, &xobj->base, &args->handle);
	if (ret)
		goto out1;

	xobj->flags |= XOCL_BO_USERPTR;
	xocl_describe(xobj);
	drm_gem_object_unreference_unlocked(&xobj->base);
	return ret;

out0:
	drm_free_large(xobj->pages);
	xobj->pages = NULL;
out1:
	xocl_free_bo(&xobj->base);
	DRM_DEBUG("handle creation failed\n");
	return ret;
}

int xocl_map_bo_ioctl(struct drm_device *dev,
		      void *data,
		      struct drm_file *filp)
{
	int ret = 0;
	struct drm_xocl_map_bo *args = data;
	struct drm_gem_object *obj;

	obj = xocl_gem_object_lookup(dev, filp, args->handle);
	if (!obj) {
		DRM_ERROR("Failed to look up GEM BO %d\n", args->handle);
		return -ENOENT;
	}

	if (xocl_bo_userptr(to_xocl_bo(obj))) {
		ret = -EPERM;
		goto out;
	}
	/* The mmap offset was set up at BO allocation time. */
	args->offset = drm_vma_node_offset_addr(&obj->vma_node);
	xocl_describe(to_xocl_bo(obj));
out:
	drm_gem_object_unreference_unlocked(obj);
	return ret;
}

static struct sg_table *alloc_onetime_sg_table(struct page **pages, uint64_t offset, uint64_t size)
{
	int ret;
	unsigned int nr_pages;
	struct sg_table *sgt = kmalloc(sizeof(struct sg_table), GFP_KERNEL);
	if (!sgt)
		return ERR_PTR(-ENOMEM);

	pages += (offset >> PAGE_SHIFT);
	offset &= (~PAGE_MASK);
	nr_pages = PAGE_ALIGN(size + offset) >> PAGE_SHIFT;

	ret = sg_alloc_table_from_pages(sgt, pages, nr_pages, offset, size, GFP_KERNEL);
	if (ret)
		goto cleanup;
	return sgt;

cleanup:
	kfree(sgt);
	return ERR_PTR(-ENOMEM);
}

static int acquire_channel(struct drm_xocl_dev *xdev, enum drm_xocl_sync_bo_dir dir)
{
	int channel = 0;
        int result = 0;

	if (down_interruptible(&xdev->channel_sem[dir])) {
		channel = -ERESTARTSYS;
		goto out;
	}

        for (channel = 0; channel < xdev->channel; channel++) {
		result = test_and_clear_bit(channel, &xdev->channel_bitmask[dir]);
		if (result)
			break;
        }
        if (!result) {
		// How is this possible?
		DRM_ERROR("Failed to acquire a valid channel\n");
		up(&xdev->channel_sem[dir]);
		channel = -EIO;
	}
out:
	return channel;
}

static void release_channel(struct drm_xocl_dev *xdev, enum drm_xocl_sync_bo_dir dir, int channel)
{
        set_bit(channel, &xdev->channel_bitmask[dir]);
        up(&xdev->channel_sem[dir]);
}


int xocl_sync_bo_ioctl(struct drm_device *dev,
		       void *data,
		       struct drm_file *filp)
{
	int channel = 0;
	const struct drm_xocl_sync_bo *args = data;
	struct drm_gem_object *gem_obj = xocl_gem_object_lookup(dev, filp,
							       args->handle);
	struct drm_xocl_dev *xdev = dev->dev_private;
	const bool dir = (args->dir == DRM_XOCL_SYNC_BO_TO_DEVICE) ? true : false;
	const struct drm_xocl_bo *xobj = to_xocl_bo(gem_obj);
	struct sg_table *sgt = xobj->sgt;
	u64 paddr = xobj->mm_node->start;
	int ret = 0;

	/* If device is offline (due to error), reject all DMA requests */
	if (xdev->offline)
		return -ENODEV;

	if (!gem_obj) {
		DRM_ERROR("Failed to look up GEM BO %d\n", args->handle);
		return -ENOENT;
	}

	if ((args->offset >= gem_obj->size) || (args->size > gem_obj->size) ||
	    ((args->offset + args->size) > gem_obj->size)) {
		ret = -EINVAL;
		goto out;
	}

	/* only invalidate the range of addresses requested by the user */
	/*
	if (args->dir == DRM_XOCL_SYNC_BO_TO_DEVICE)
		flush_kernel_vmap_range(kaddr, args->size);
	else if (args->dir == DRM_XOCL_SYNC_BO_FROM_DEVICE)
		invalidate_kernel_vmap_range(kaddr, args->size);
	else {
		ret = -EINVAL;
		goto out;
	}
	*/
	paddr += args->offset;

	if (args->offset || (args->size != xobj->base.size)) {
		sgt = alloc_onetime_sg_table(xobj->pages, args->offset, args->size);
		if (IS_ERR(sgt)) {
			ret = PTR_ERR(sgt);
			goto out;
		}
	}

	//drm_clflush_sg(sgt);
	channel = acquire_channel(xdev, args->dir);

	if (channel < 0) {
		ret = channel;
		goto clear;
	}
	/* Now perform DMA */
	ret = xdma_migrate_bo(xdev, sgt, dir, paddr, channel);
	release_channel(xdev, args->dir, channel);
	ret = (ret == args->size) ? 0 : -EIO;
clear:
	if (args->offset || (args->size != xobj->base.size))
		sg_free_table(sgt);
out:
	drm_gem_object_unreference_unlocked(gem_obj);
	return ret;
}

int xocl_info_bo_ioctl(struct drm_device *dev,
		       void *data,
		       struct drm_file *filp)
{
	const struct drm_xocl_bo *xobj;
	struct drm_xocl_info_bo *args = data;
	struct drm_gem_object *gem_obj = xocl_gem_object_lookup(dev, filp,
								args->handle);

	if (!gem_obj) {
		DRM_ERROR("Failed to look up GEM BO %d\n", args->handle);
		return -ENOENT;
	}

	xobj = to_xocl_bo(gem_obj);

	args->size = xobj->base.size;
	args->paddr = xobj->mm_node->start;
	xocl_describe(xobj);
	drm_gem_object_unreference_unlocked(gem_obj);

	return 0;
}

int xocl_pwrite_bo_ioctl(struct drm_device *dev, void *data,
			 struct drm_file *filp)
{
	struct drm_xocl_bo *xobj;
	const struct drm_xocl_pwrite_bo *args = data;
	struct drm_gem_object *gem_obj = xocl_gem_object_lookup(dev, filp,
							       args->handle);
	char __user *user_data = to_user_ptr(args->data_ptr);
	int ret = 0;
	void *kaddr;

	if (!gem_obj) {
		DRM_ERROR("Failed to look up GEM BO %d\n", args->handle);
		return -ENOENT;
	}

	if ((args->offset > gem_obj->size) || (args->size > gem_obj->size)
	    || ((args->offset + args->size) > gem_obj->size)) {
		ret = -EINVAL;
		goto out;
	}

	if (args->size == 0) {
		ret = 0;
		goto out;
	}

	if (!access_ok(VERIFY_READ, user_data, args->size)) {
		ret = -EFAULT;
		goto out;
	}

	xobj = to_xocl_bo(gem_obj);

	if (xocl_bo_userptr(xobj)) {
		ret = -EPERM;
		goto out;
	}

	kaddr = xobj->vmapping;
	kaddr += args->offset;

	ret = copy_from_user(kaddr, user_data, args->size);
out:
	drm_gem_object_unreference_unlocked(gem_obj);

	return ret;
}

int xocl_pread_bo_ioctl(struct drm_device *dev, void *data,
			struct drm_file *filp)
{
	struct drm_xocl_bo *xobj;
	const struct drm_xocl_pread_bo *args = data;
	struct drm_gem_object *gem_obj = xocl_gem_object_lookup(dev, filp,
							       args->handle);
	char __user *user_data = to_user_ptr(args->data_ptr);
	int ret = 0;
	void *kaddr;

	if (!gem_obj) {
		DRM_ERROR("Failed to look up GEM BO %d\n", args->handle);
		return -ENOENT;
	}

	if (xocl_bo_userptr(to_xocl_bo(gem_obj))) {
		ret = -EPERM;
		goto out;
	}

	if ((args->offset > gem_obj->size) || (args->size > gem_obj->size)
	    || ((args->offset + args->size) > gem_obj->size)) {
		ret = -EINVAL;
		goto out;
	}

	if (args->size == 0) {
		ret = 0;
		goto out;
	}

	if (!access_ok(VERIFY_WRITE, user_data, args->size)) {
		ret = EFAULT;
		goto out;
	}

	xobj = to_xocl_bo(gem_obj);
	kaddr = xobj->vmapping;;
	kaddr += args->offset;

	ret = copy_to_user(user_data, kaddr, args->size);

out:
	drm_gem_object_unreference_unlocked(gem_obj);

	return ret;
}

struct sg_table *xocl_gem_prime_get_sg_table(struct drm_gem_object *obj)
{
	struct drm_xocl_bo *xobj = to_xocl_bo(obj);
	return drm_prime_pages_to_sg(xobj->pages, xobj->base.size >> PAGE_SHIFT);
}

struct drm_gem_object *xocl_gem_prime_import_sg_table(struct drm_device *dev,
						      struct dma_buf_attachment *attach, struct sg_table *sgt)
{
	int ret = 0;
	struct drm_xocl_bo *xobj = xocl_create_bo(dev, attach->dmabuf->size, 0);

	if (IS_ERR(xobj)) {
		DRM_DEBUG("object creation failed\n");
		return (struct drm_gem_object *)xobj;
	}

	xobj->flags |= XOCL_BO_IMPORT;
	xobj->sgt = sgt;
	xobj->pages = drm_malloc_ab(attach->dmabuf->size >> PAGE_SHIFT, sizeof(*xobj->pages));
	if (!xobj->pages) {
		ret = -ENOMEM;
		goto out_free;
	}

	ret = drm_prime_sg_to_page_addr_arrays(sgt, xobj->pages,
					       NULL, attach->dmabuf->size >> PAGE_SHIFT);

	xobj->vmapping = vmap(xobj->pages, xobj->base.size >> PAGE_SHIFT, VM_MAP,
			      pgprot_writecombine(PAGE_KERNEL));

	if (!xobj->vmapping) {
		ret = -ENOMEM;
		goto out_free;
	}

	ret = drm_gem_create_mmap_offset(&xobj->base);
	if (ret < 0)
		goto out_free;

	xocl_describe(xobj);
	return &xobj->base;

out_free:
	xocl_free_bo(&xobj->base);
	DRM_DEBUG("Buffer import failed\n");
	return ERR_PTR(ret);
}

void *xocl_gem_prime_vmap(struct drm_gem_object *obj)
{
	struct drm_xocl_bo *xobj = to_xocl_bo(obj);
	return xobj->vmapping;
}

void xocl_gem_prime_vunmap(struct drm_gem_object *obj, void *vaddr)
{

}

int xocl_create_ctx_ioctl(struct drm_device *dev, void *data,
			  struct drm_file *filp)
{
	return 0;
}

static int xocl_init_unmgd(struct drm_xocl_unmgd *unmgd, uint64_t data_ptr, uint64_t size,
			   enum drm_xocl_sync_bo_dir dir)
{
	int ret;
	char __user *user_data = to_user_ptr(data_ptr);

	if (!access_ok((dir == DRM_XOCL_SYNC_BO_TO_DEVICE) ? VERIFY_READ : VERIFY_WRITE, user_data, size))
		return -EFAULT;

	memset(unmgd, 0, sizeof(struct drm_xocl_unmgd));

	unmgd->npages = (((unsigned long)user_data + size + PAGE_SIZE - 1) -
			((unsigned long)user_data & PAGE_MASK)) >> PAGE_SHIFT;

	unmgd->pages = drm_malloc_ab(unmgd->npages, sizeof(*unmgd->pages));
	if (!unmgd->pages)
		return -ENOMEM;

	ret = get_user_pages_fast(data_ptr, unmgd->npages, (dir == DRM_XOCL_SYNC_BO_FROM_DEVICE) ? 1 : 0, unmgd->pages);

	if (ret != unmgd->npages)
		goto clear_pages;

	unmgd->sgt = alloc_onetime_sg_table(unmgd->pages, data_ptr & ~PAGE_MASK, size);
	if (IS_ERR(unmgd->sgt)) {
		ret = PTR_ERR(unmgd->sgt);
		goto clear_release;
	}

	return 0;

clear_release:
	release_pages(unmgd->pages, unmgd->npages, 0);
clear_pages:
	drm_free_large(unmgd->pages);
	unmgd->pages = NULL;
	return ret;
}

static void xocl_finish_unmgd(struct drm_xocl_unmgd *unmgd)
{
	if (!unmgd->pages)
		return;
	release_pages(unmgd->pages, unmgd->npages, 0);
	drm_free_large(unmgd->pages);
	unmgd->pages = NULL;
}


int xocl_pwrite_unmgd_ioctl(struct drm_device *dev, void *data,
			    struct drm_file *filp)
{
	int channel;
	struct drm_xocl_unmgd unmgd;
	const struct drm_xocl_pwrite_unmgd *args = data;
	struct drm_xocl_dev *xdev = dev->dev_private;
	const enum drm_xocl_sync_bo_dir dir = DRM_XOCL_SYNC_BO_TO_DEVICE;
	int ret = 0;

	if (args->address_space != 0)
		return -EFAULT;

	if (args->size == 0)
		return 0;

	DRM_DEBUG("%s:%d\n", __func__, __LINE__);
	ret = xocl_init_unmgd(&unmgd, args->data_ptr, args->size, dir);
	if (ret)
		return ret;

	channel = acquire_channel(xdev, dir);
	DRM_DEBUG("%s:%d\n", __func__, __LINE__);
	if (channel < 0) {
		ret = channel;
		goto clear;
	}
	/* Now perform DMA */
	ret = xdma_migrate_bo(xdev, unmgd.sgt, (dir == DRM_XOCL_SYNC_BO_TO_DEVICE), args->paddr, channel);
	release_channel(xdev, dir, channel);
	ret = (ret == args->size) ? 0 : -EIO;
	DRM_DEBUG("%s:%d\n", __func__, __LINE__);
clear:
	xocl_finish_unmgd(&unmgd);
	return ret;
}

int xocl_pread_unmgd_ioctl(struct drm_device *dev, void *data,
			   struct drm_file *filp)
{
	int channel;
	struct drm_xocl_unmgd unmgd;
	const struct drm_xocl_pwrite_unmgd *args = data;
	struct drm_xocl_dev *xdev = dev->dev_private;
	const enum drm_xocl_sync_bo_dir dir = DRM_XOCL_SYNC_BO_FROM_DEVICE;
	int ret = 0;

	DRM_DEBUG("%s:%d\n", __func__, __LINE__);
	if (args->address_space != 0)
		return -EFAULT;

	if (args->size == 0)
		return 0;

	ret = xocl_init_unmgd(&unmgd, args->data_ptr, args->size, dir);
	if (ret)
		return ret;

	DRM_DEBUG("%s:%d\n", __func__, __LINE__);
	channel = acquire_channel(xdev, dir);

	if (channel < 0) {
		ret = channel;
		goto clear;
	}
	/* Now perform DMA */
	ret = xdma_migrate_bo(xdev, unmgd.sgt, (dir == DRM_XOCL_SYNC_BO_TO_DEVICE), args->paddr, channel);
	release_channel(xdev, dir, channel);
	ret = (ret == args->size) ? 0 : -EIO;

	DRM_DEBUG("%s:%d\n", __func__, __LINE__);
clear:
	xocl_finish_unmgd(&unmgd);
	return ret;
}
