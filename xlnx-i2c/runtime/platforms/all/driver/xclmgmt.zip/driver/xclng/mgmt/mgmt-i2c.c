/**
 *  Copyright (C) 2017 Xilinx, Inc. All rights reserved.
 *
 *  I2C driver module
 *  Author: Umang Parekh
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 */

#include "mgmt-core.h"

/**
 * AXI IIC Bus Interface v2.0
 * http://www.xilinx.com/support/documentation/ip_documentation/axi_iic/v2_0/pg090-axi-iic.pdf
 */
#define AXI_I2C_SOFT_RESET      AXI_I2C_BASE+0x040
#define AXI_I2C_CR              AXI_I2C_BASE+0x100
#define AXI_I2C_TX_FIFO         AXI_I2C_BASE+0x108
#define AXI_I2C_RX_FIFO         AXI_I2C_BASE+0x10c
#define AXI_I2C_RX_FIFO_PIRQ    AXI_I2C_BASE+0x120

/*
 * Early code for LM96063
 */
void fan_controller(const struct xclmgmt_dev *lro)
{
	unsigned int pwm_config_reg;
	unsigned int MAX_TACH_THRESHOLD = 0x250;
	unsigned int sleep_counter = 0;
	unsigned int FAN_SPIN_DOWN_TIME = 24; // this will result in roughly a 2 second delay
	unsigned int tach_value = 0;
	unsigned int tach_reg_lsb = 0; // LS Byte
	unsigned int tach_reg_msb = 0; // MS Byte
	// Execute only for TUL based DSA's
	if (	lro->pci_dev->device == 0x4A27 ||
		lro->pci_dev->device == 0x4B27 ||
		lro->pci_dev->device == 0x682F ||
		lro->pci_dev->device == 0x692F
	)
		printk(KERN_INFO "%s: TUL fan setup, Version 1.2 \n", DRV_NAME);
	else
		return;

	iowrite32(0xa,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_SOFT_RESET);   // theepanm: we reset the AXI_I2C controller
	msleep(100);
	msleep(100);
	iowrite32(0xf,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_RX_FIFO_PIRQ); // theepanm: set interupt depth to the full 16-entries amount
	iowrite32(0x2,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	  // theepanm: set the clear TX-FIFO bit
	iowrite32(0x0,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	  // theepanm: undo the previous set-bit, such that TX-FIFO can resume normal operation

	iowrite32(0x1e8,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);   // theepanm: this commands selects the I2C mux as our Slave-Device, as defined by its address: 0xE8
	iowrite32(0x208,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);   // theepanm: now we configure it's control registers such that we let it know that we want to access Channel 3 (which connects to the FAN)
	iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);        // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that were previously pushed into the TX_FIFO.
	msleep(100);

	// We want to read the PWM polarity bit ...
	pwm_config_reg = 0xABCDEFED;
	iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
	iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
	iowrite32(0x4a ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x4A : FAN PWM CONFIGURATION REGISTER
	iowrite32(0x199,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x199 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Read bit
	iowrite32(0x200,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue I2C Stop
	iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
	msleep(100); // we wait for the transmission bytes to go out, and for the FAN to respond by writing to our own RX_FIFO

	pwm_config_reg = ioread32(lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_RX_FIFO); // theepanm: we read from the RX_FIFO and store its value into the local pwm_config_reg variable
	printk(KERN_INFO "%s: The value of the PWM CONFIG REG is: %x \n", DRV_NAME, pwm_config_reg);

	if ((0x00000010 & pwm_config_reg) != 0) return; // bit 4 is the PWM polarity bit within pwm_config_reg, so we mask all other bits
	// if the above condition is met this means that the PWM polarity bit has already been set, so we do nothing
	else {
		printk(KERN_INFO "%s: We have detected that the polarity bit was NOT set previously.\n", DRV_NAME);
		// unsigned int config_reg = 0; // debug variable only

		// Set the Polarity Bit.
		// Most of our newer boards are now reversed-polarity boards (meaning the FAN spins high on power on, for safety, even though the PWM values on power on are still at 0).
		// Because of this we are going to set the polarity-bit as the default procedure to match the newer boards that we have.
		// If in the rare case that we're still dealing with an older board that should NOT have the polarity bit, our algorithm below will detect this, and undo the polarit-bit setting
		// that takes place in the next few lines.
		iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
		iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
		iowrite32(0x4a ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x4A : FAN PWM CONFIGURATION REGISTER
		iowrite32(0x230,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x230 = I2C Stop + Write-Byte
										// In binary we are also going to keep bit 5 of the PWM ConFig Register on (PWPGM PWM Programming Enable),
										// along with us now setting the polarity bit (i.e. 0011 0000 or 0x30).
										// Bit [5] in this register is enabled by defualt during Power-On and allows you to program the Tmp. to Fan-Speed Look-up-Table.
										// Once you've finished programming the table, and you actually want the fan controller to start using the table, you must de-set this bit.
										// We will de-set bit later on once we have actually programmed the Look-up-Table temperatures below.
		iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
		msleep(100);
		
		// Set Fan to a high RPM value. If we're dealing with an older non reversed-polarity board, this will actually set the fan to a low RPM (because we just set the polarity bit above).
		// We'll detect this drop in fan speed if we're dealing with an older board in the following steps to come once fan has had a second or two to actually spin down (if indeed it is an older board).
		iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
		iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
		iowrite32(0x4c ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x4A : FAN PWM CONFIGURATION REGISTER
		iowrite32(0x23f,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x230 = I2C Stop + Write-Byte (0x3f), PWM low resolution only uses 6 bits, thus 0x3f is the max.
		iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
		// Give the fan some time to physically spin down at a lower RPM if it is going to.
		for (sleep_counter = 0; sleep_counter <FAN_SPIN_DOWN_TIME; sleep_counter++) msleep(100);

		// The above step should keep the fan still spinning high on newer boards, if the opposite occurs (i.e. on an older board), we will soon detect this and un-set the reverse polarity bit accordingly.


		// Program the Temperature to Fan Speed Look-up-Table
		// Tmp > 0  degrees Celsius = 30%  Fan Speed
		// Tmp > 50 degrees Celsius = 50%  Fan Speed
		// Tmp > 70 degrees Celsius = 65%  Fan Speed
		// Tmp > 80 degrees Celsius = 75%  Fan Speed
		// Tmp > 90 degrees Celsius = 100% Fan Speed

		// Program the first Tmp > 0 degrees = 30% Fan Speed entry.
		iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
		iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
		iowrite32(0x50 ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x4A : FAN PWM CONFIGURATION REGISTER
		iowrite32(0x200,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x230 = I2C Stop + Write-Byte (0x00 Temperature Value)
		iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
		msleep(100);
		iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
		iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
		iowrite32(0x51 ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x4A : FAN PWM CONFIGURATION REGISTER
		iowrite32(0x20E,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x230 = I2C Stop + Write-Byte (0x0E = PWM Value 14 in decimal)
		// For debugging, we can set the first entry in the table to 100% so that we can hear the fan.
		//iowrite32(0x22E,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x230 = I2C Stop + Write-Byte (0x0E = PWM Value 14 in decimal)
		iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
		msleep(100);

		// Program the first Tmp > 50 degrees = 50% Fan Speed entry.
		iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
		iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
		iowrite32(0x52 ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x4A : FAN PWM CONFIGURATION REGISTER
		iowrite32(0x232,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x230 = I2C Stop + Write-Byte (0x32 Temperature Value = 50 degrees in decimal)
		iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
		msleep(100);
		iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
		iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
		iowrite32(0x53 ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x4A : FAN PWM CONFIGURATION REGISTER
		iowrite32(0x217,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x230 = I2C Stop + Write-Byte (0x17 = PWM Value 23 in decimal)
		iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
		msleep(100);


		// Program the first Tmp > 70 degrees = 65% Fan Speed entry.
		iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
		iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
		iowrite32(0x54 ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x4A : FAN PWM CONFIGURATION REGISTER
		iowrite32(0x246,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x230 = I2C Stop + Write-Byte (0x46 Temperature Value = 70 degrees in decimal)
		iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
		msleep(100);
		iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
		iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
		iowrite32(0x55 ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x4A : FAN PWM CONFIGURATION REGISTER
		iowrite32(0x21E,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x230 = I2C Stop + Write-Byte (0x1E = PWM Value 30 in decimal)
		iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
		msleep(100);


		// Program the first Tmp > 80 degrees = 75% Fan Speed entry.
		iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
		iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
		iowrite32(0x56 ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x4A : FAN PWM CONFIGURATION REGISTER
		iowrite32(0x250,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x230 = I2C Stop + Write-Byte (0x00 Temperature Value = 80 degrees in decimal)
		iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
		msleep(100);
		iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
		iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
		iowrite32(0x57 ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x4A : FAN PWM CONFIGURATION REGISTER
		iowrite32(0x223,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x230 = I2C Stop + Write-Byte (0x23 = PWM Value 35 in decimal)
		iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
		msleep(100);


		// Program the first Tmp > 90 degrees = 100% Fan Speed entry.
		iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
		iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
		iowrite32(0x58 ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x4A : FAN PWM CONFIGURATION REGISTER
		iowrite32(0x25a,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x230 = I2C Stop + Write-Byte (0x00 Temperature Value = 90 degrees in decimal)
		iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
		msleep(100);
		iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
		iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
		iowrite32(0x59 ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x4A : FAN PWM CONFIGURATION REGISTER
		iowrite32(0x22E,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x230 = I2C Stop + Write-Byte (0x2E = PWM Value 46 in decimal)
		iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
		msleep(100);

		// Ends the Programming of the Temperature to Fan RMP% Programming
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		// We will now check the fan's current tachometer value ...
		// First we enable the tachometer enable bit [2] within the 0x03 CONFIGURATION REGISTER
		iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
		iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
		iowrite32(0x03 ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x03 : CONFIGURATION REGISTER
		iowrite32(0x204,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x204 Coresponds to I2C Stop + setting the tachmoeter enable bit [2] to 1 with a 0x04
		iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
		msleep(100);

		/*
		// This read was for debug purposes only.
		// Let's check to see if the Configuration Register has tachometer read enable bit set properly...
		iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
		iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
		iowrite32(0x03 ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x46 : TACHOMETER COUNT LSB
		iowrite32(0x199,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x199 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Read bit
		iowrite32(0x200,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue I2C Stop
		iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
		msleep(100); // we wait for the transmission bytes to go out, and for the FAN to respond by writing to our own RX_FIFO
		config_reg = ioread32(lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_RX_FIFO); // theepanm: we read from the RX_FIFO and store its value into the local tach_reg_lsb variable
		printk(KERN_INFO "%s: The value in the config reg is: %x \n", DRV_NAME, config_reg);
		*/

		// read the LSB reg first, to lock the MSB
		iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
		iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
		iowrite32(0x46 ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x46 : TACHOMETER COUNT LSB
		iowrite32(0x199,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x199 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Read bit
		iowrite32(0x200,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue I2C Stop
		iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
		msleep(100); // we wait for the transmission bytes to go out, and for the FAN to respond by writing to our own RX_FIFO
		tach_reg_lsb = ioread32(lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_RX_FIFO); // theepanm: we read from the RX_FIFO and store its value into the local tach_reg_lsb variable
		printk(KERN_INFO "%s: The value of tach_reg_lsb is: %x \n", DRV_NAME, tach_reg_lsb);

		// now read the MSB
		iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
		iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
		iowrite32(0x47 ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x47 : TACHOMETER COUNT MSB
		iowrite32(0x199,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x199 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Read bit
		iowrite32(0x200,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue I2C Stop
		iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
		msleep(100); // we wait for the transmission bytes to go out, and for the FAN to respond by writing to our own RX_FIFO
		tach_reg_msb = ioread32(lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_RX_FIFO); // theepanm: we read from the RX_FIFO and store its value into the local tach_reg_msb variable
		printk(KERN_INFO "%s: The value of tach_reg_msb is: %x \n", DRV_NAME, tach_reg_msb);

		tach_value   = tach_reg_msb;
		tach_value   = (tach_value<<8);
		printk(KERN_INFO "%s: The tach_value after an 8-bit shift to the left: %x \n", DRV_NAME, tach_value);
		tach_reg_lsb = (0x000000FF & tach_reg_lsb);   // ensure that all other bytes except the LSB is masked
		printk(KERN_INFO "%s: The value of tach_reg_lsb after masking all the upper bytes: %x \n", DRV_NAME, tach_reg_lsb);
		tach_value   = (tach_value | tach_reg_lsb);   // we should now have the last 16-bits of tach_value set to MSB + LSB
		printk(KERN_INFO "%s: The value of tach_value after ORing tach_value with tach_reg_lsb: %x \n", DRV_NAME, tach_value);
		tach_value   = (tach_value>>2);
		printk(KERN_INFO "%s: The final value of tach_value after dropping the last two bits is: %x \n", DRV_NAME, tach_value);


		if (tach_value > MAX_TACH_THRESHOLD) {
			printk(KERN_INFO "%s: We have detected that the fan's RPM is too slow, and thus we're dealing with an older non reversed-polarity board.\n", DRV_NAME);
			// Un-Set the Polarity Bit
			iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
			iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
			iowrite32(0x4a ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x4A : FAN PWM CONFIGURATION REGISTER
			iowrite32(0x200,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x230 = I2C Stop + Write-Byte
										// In binary we are now also going to turn off bit 5 of the PWM ConFig Register (PWPGM PWM Programming Enable),
										// along with us now UN-setting the polarity bit (i.e. 0000 0000 or 0x00).
										// Bit [5] in this register is enabled by defualt during Power-On and allows you to program the Tmp. to Fan-Speed Look-up-Table.
										// Once you've finished programming the table, and you actually want the fan controller to start using the table, you must de-set this bit.
			iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
			msleep(100);
		}
		else {
			// Just turn off the PWM Programming Enable bit, and leave the Polarity Bit as is in the Set position.
			iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
			iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
			iowrite32(0x4a ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x4A : FAN PWM CONFIGURATION REGISTER
			iowrite32(0x210,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x230 = I2C Stop + Write-Byte (0x10)
										// We are turning off bit 5 (PWPGM: PWM Programming Enable bit) of the PWM ConFig Register.
										// Bit 5 in this register is enabled by defualt during Power-On and allows you to program the Tmp. to Fan-Speed Look-up-Table.
										// Once you've finished programming the table, and you actually want the fan controller to start using the table, you must de-set this bit.
			iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
			msleep(100);

		}
	
	// Set the Critical Temparture point at which Regulator shutoff occurs to 96 degrees celcius.
	// First we enable the tachometer enable bit [1] within the 0x03 CONFIGURATION REGISTER
	iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
	iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
	iowrite32(0x03 ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x03 : CONFIGURATION REGISTER
	iowrite32(0x206,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x204 Coresponds to I2C Stop + setting the tcrit overide bit [1] to 1, while keeping the tachmoeter enable bit [2] to 1 with a 0x06 (4'b0110).
	iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
	msleep(100);

	// Set the critical temp register to 96 degrees bit[7] is sign bit=0 for positive degrees + bit[6]=1 for 64 degrees + bit[5]=1 for 32 degrees = 8'b0110_0000 = 0x60 
	iowrite32(0x0  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR); 	// theepanm: disables the Controller, we always do this before we push a new set of commands into the TX_FIFO
	iowrite32(0x198,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x198 Coresponds to I2C Start + the Fan's Slave-Address (7-bits hardwired) + LSB-Write bit
	iowrite32(0x19 ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: issue the fan's register address: 0x03 : CONFIGURATION REGISTER
	iowrite32(0x260,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_TX_FIFO);  // theepanm: 0x204 Coresponds to I2C Stop + setting the temp value 0x60
	iowrite32(0x1  ,lro->bar[XCLMGMT_MAIN_BAR] + AXI_I2C_CR);       // theepanm: enables the AXI_I2C Controller, this basically kicks off the start of the transmission bytes that we just pushed into the TX_FIFO.
	msleep(100);
	
	}
	return;
}

